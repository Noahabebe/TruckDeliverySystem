#pragma once
#ifndef TEST_R_H
#define TEST_R_H
extern "C"
{
#include <Test.h>
}
#endif