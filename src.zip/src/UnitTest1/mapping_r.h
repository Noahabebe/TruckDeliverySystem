#pragma once
#ifndef MAPPING_R_H
#define MAPPING_R_H
extern "C"
{
#include <mapping.h>
}
#endif