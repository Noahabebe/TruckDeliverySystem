#pragma once
#ifndef TRUCK_R_H
#define TRUCK_R_H
extern "C"
{
#include <Truck.h>
}
#endif